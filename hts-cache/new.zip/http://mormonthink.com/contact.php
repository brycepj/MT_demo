<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<!-- InstanceBegin template="/Templates/template.dwt.php" codeOutsideHTMLIsLocked="true" -->

<head>


<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="google-site-verification" content="B-mpb8c2n82WjGwz9HaoOYpwpEtiRRnasS4D1kIIlyE" /> 

<!-- InstanceBeginEditable name="doctitle" --><title>MormonThink - Contact Us</title><!-- InstanceEndEditable -->

<!-- InstanceBeginEditable name="metadesc" --><meta name="Description" content="Contact MormonThink for ideas, suggestions, questions, help, etc."/><!-- InstanceEndEditable -->

<!-- InstanceBeginEditable name="metakeywords" --><meta name="Keywords" content="MormonThink,ideas,suggestions,questions,help,contact,contact us,email,email us"/><!-- InstanceEndEditable -->

<link href="/main5.css" rel="stylesheet" type="text/css" title="style" />
<link rel="alternate" type="application/rss+xml" title="New Content via RSS" href="http://feeds.feedburner.com/MormonThink" />

<link rel="icon" href="/img/favicon.ico" type="image/x-icon" />

<!-- <script type="text/javascript" src="/pd.js"></script> -->

<script type="text/javascript" src="/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="/jqueryhashchange.js"></script>
<script type="text/javascript" src="/main5.js"></script><br/>
<script type="text/javascript" src="http://www.mormonthink.com/contact-files/contact-form.js"></script>

<meta property="og:image" content="http://www.mormonthink.com/img/thumbnail.jpg" />
<meta property="og:image:type" content="image/jpeg" /> 
<meta property="og:image:width" content="200" /> 
<meta property="og:image:height" content="200" />
<link rel="image_src" href="http://mormonthink.com/img/thinker_home.png" />

</head>

<body>
<script type="text/javascript" src="/tooltip/wz_tooltip.js"></script>

<div class="wrapper" id="wrapper">

 
 		 <!-- Header Begins - logo, search, language --> 
			<table id="header" border="0">
				<tr>
					<td>
						<a href="/"><img alt="" src="/img/logo_banner3.png" title="Home" /></a>
					</td>
					<td>
					</td>
					<td>
						<span style="white-space: nowrap;"><a href="/">Home</a> <a href="/foreign.htm">English</a> <a href="http://www.facebook.com/pages/MormonThinkcom/185572458250693">Facebook</a> <a href="/donations.htm">Donate</a></span>
						<form name="cse-search-box" action="http://mormonthink.com/search-results.htm" id="cse-search-box">
							<input type="hidden" name="cx" value="015460835189005166853:f_xa5cotdmg" />
							<input type="hidden" name="cof" value="FORID:9" />
							<input type="hidden" name="ie" value="UTF-8" />
							<input type="text" name="q" size="31" />
							<img alt="" src="/img/search.jpg" style="position:relative;top:8px;left:0px;margin:0;border:0;padding:0;" onclick="javascript:document.forms['cse-search-box'].submit();" />
							<input type="hidden" name="safe" value="off" />
							<!-- <input type="submit" name="sa" value="Search" /> -->
						</form>
						<script type="text/javascript" src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en"></script>
					</td>
				</tr>
			</table>
		<!-- Header End -->	
			
		<!-- Menu Bar Start -->
			<div id="tbar_anchor" class="tbar_anchor"></div>
			<div class="tbar">
				<div id="tbar_space">
				</div>
				<span class="menu_push_right">
					<ul class="nav_bar_menu">
						<li class="nav_drop_down"><a>Book of Mormon</a>
							<ul class="nav_main_heading">
								<li class="nav_drop_down"><a href="/transbomweb.htm">Translation</a></li>
								<li class="nav_drop_down"><a href="/book-of-mormon-problems.htm">Problems</a></li>
								<li class="nav_drop_down"><a href="/lost116web.htm">Lost 116 Pages</a></li>
								<li class="nav_drop_down"><a href="/josephweb.htm">Could Joseph have Written it?</a></li>
								<li class="nav_drop_down"><a href="/witnessesweb.htm">The Witnesses</a></li>
								<li class="nav_drop_down"><a href="/influences.htm">Early American Influences</a></li>
								<li class="nav_drop_down"><a href="/mormonstudies.htm">Book of Mormon Studies</a></li>
							</ul>
						</li>

						<li class="nav_drop_down"><a>Joseph Smith</a>
							<ul class="nav_bar_menu"> 
								<li class="nav_drop_down"><a href="/moroniweb.htm">Moroni's Visitation</a></li>
								<li class="nav_drop_down"><a href="/firstvisionweb.htm">First Vision</a></li>
								<li class="nav_drop_down"><a href="/book-of-abraham-issues.htm">Book of Abraham</a></li>
								<li class="nav_drop_down"><a href="/kinderhookweb.htm">Kinderhook Plates</a></li>
								<li class="nav_drop_down"><a href="/jst.htm">Translation of the Bible</a></li>
								<li class="nav_drop_down"><a href="/zelph.htm">Zelph</a></li>
								<li class="nav_drop_down"><a href="/nephiweb.htm">Moroni or Nephi?</a></li>
								<li class="nav_drop_down"><a href="/runningweb.htm">Running with Gold Plates</a></li>
							</ul>
						</li>

						<li class="nav_drop_down"><a>History</a>
							<ul class="nav_bar_menu">
								<li class="nav_drop_down"><a href="/joseph-smith-polygamy.htm">Polygamy</a></li>
								<li class="nav_drop_down"><a href="/blackweb.htm">Blacks &amp; Priesthood</a></li>
								<li class="nav_drop_down"><a href="/prophetsweb.htm">Prophets After Joseph</a></li>
								<li class="nav_drop_down"><a href="/greekweb.htm">Greek Psalter Incident</a></li>
								<li class="nav_drop_down"><a href="/nameweb.htm">The Name of the Church</a></li>
								<li class="nav_drop_down"><a href="/priesthood.htm">Priesthood Restoration</a></li>
								<li class="nav_drop_down"><a href="/rodofaaron.htm">Rod of Aaron</a></li>
							</ul>
						</li>

						<li class="nav_drop_down"><a>Doctrine</a>
							<ul class="nav_bar_menu">
								<li class="nav_drop_down"><a href="/scienceweb.htm">Conflicts with Science</a></li>
								<li class="nav_drop_down"><a href="/tithing.htm">Tithing</a></li>
								<li class="nav_drop_down"><a href="/temple.htm">Temple/Masonry</a></li>
								<li class="nav_drop_down"><a href="/lying.htm">Lying for the Lord</a></li>
								<li class="nav_drop_down"><a href="/wow.htm">Word of Wisdom</a></li>
								<li class="nav_drop_down"><a href="/d&amp;c.htm">D&amp;C</a></li>
								<li class="nav_drop_down"><a href="/testimonyweb.htm">Testimony &amp; Spiritual Witnesses</a></li>
							</ul>
						</li>
	
						<li class="nav_drop_down"><a>Other</a>
							<ul class="nav_bar_menu">
								<li class="nav_drop_down"><a href="/introductionweb.htm" title="Introduction to the MormonThink website">Introduction</a></li>
								<li class="nav_drop_down"><a href="/whoarewe.htm" title="About those behind MormonThink">Who Are We?</a></li>
								<li class="nav_drop_down"><a href="/endpage.htm" title="I've read it all, now what?">Conclusions</a></li>
								<li class="nav_drop_down"><a href="/glossary/index.htm" title="Glossary and Miscellaneous topics">Glossary &amp; Misc. Topics</a></li>
								<li class="nav_drop_down"><a href="/QUOTES/mormonquotes.htm">Mormon Quotes</a></li>
								<li class="nav_drop_down"><a href="/personalstories.htm">Personal Stories</a></li>
							</ul>
						</li>
						
						<li class="nav_drop_down"><a>Media</a>
							<ul class="nav_bar_menu">
								<li class="nav_drop_down"><a href="/mormonstories.htm">Podcasts</a></li>
								<li class="nav_drop_down"><a href="/books.htm">Books</a></li>
								<li class="nav_drop_down"><a href="/youtube.htm">Youtube Videos</a></li>
								<li class="nav_drop_down"><a href="/dvd.htm">DVDs</a></li>
							</ul>
						</li>

						<li class="nav_drop_down"><a>Links</a>
							<ul class="nav_main_heading">
								<li class="nav_drop_down"><a href="/ldslinks.htm" title="MormonThink's full list of links">Recommended links</a></li>
								<li class="nav_drop_down"><a href="http://youtu.be/4ac_fLUHiBw" title="Video discussing the most troubling problems of the LDS church that most Mormons don't know exist.">Top 10 LDS Problems Explained</a></li>
								<li class="nav_drop_down"><a href="http://www.moretruthfoundation.com/" title="More Truth Foundation">More Truth Foundation</a></li>
								<li class="nav_drop_down"><a href="http://www.moretruthfoundation.com/howtohelp.html" title="How to Help - Telling Others">Informing Other Members</a></li>
								<li class="nav_drop_down"><a href="/files/sunstone.pdf" title="Article: The Founders of MormonThink">Founders of MormonThink</a></li>
								<li class="nav_drop_down"><a href="/fair.htm" title="How fair is FAIR?">Is FAIR fair?</a></li>
							</ul>
						</li>

						<li class="nav_drop_down"><a>Church Essays</a>
							<ul class="nav_bar_menu">
								<li class="nav_drop_down"><a href="/essays-responses-intro.htm">Introduction to Essays</a></li>
								<li class="nav_drop_down"><a href="/essays-race-priesthood.htm">Race and the Priesthood</a></li>
								<li class="nav_drop_down"><a href="/essays-plural-marriage.htm">Plural Marriage</a></li>
								<li class="nav_drop_down"><a href="/essays-first-vision.htm">First Vision Accounts</a></li>
								<li class="nav_drop_down"><a href="/essays-bom-translation.htm">Book of Mormon Translation</a></li>
								<li class="nav_drop_down"><a href="/essays-bom-dna.htm">Book of Mormon &amp; DNA</a></li>
								<li class="nav_drop_down"><a href="/essays-becoming-like-god.htm">Becoming Like God</a></li>
								<li class="nav_drop_down"><a href="/essays-are-mormons-christian.htm">Are Mormons Christian?</a></li>
							</ul>
						</li>

					</ul>
				</span>
			</div>
		<!-- Menu Bar End -->
 
 <img alt="" src="/img/thinker.gif" id="sidethinker" /> 
 

 <table border="0" width="100%">
 <tr>
 <td valign="top">
 <div class="bodytext" id="bodytext">
 <div id="js_section" class="invisible" style="width:100%">
 </div>
 
<!-- Main Body Start --> 
 <div id="html_content">
 
 <a name="top"></a>
 
 <!-- InstanceBeginEditable name="page name" -->
 <h1>Contact Us</h1>
 <!-- InstanceEndEditable --><br />
 
 <!-- InstanceBeginEditable name="body" -->

 
<p>Please use the following form to contact MormonThink. We will do our best to quickly follow up as long as you provide a valid email address.</p>
<!-- Fast Secure Contact Form PHP plugin 3.1 - begin - FastSecureContactForm.com -->
<div id="FSCForm1" style="width:375px;">
<form enctype="multipart/form-data" action="http://mormonthink.com/contact.php#FSCForm1" id="fsc_form1" method="post">
<div style="text-align:left;">
<span class="required"> *</span>(denotes required field)</div>

        <div style="text-align:left; padding-top:5px;">
                <label for="fsc_CID1">Department to Contact:<span class="required"> *</span></label>
        </div>
        <div style="text-align:left;">
                
                <select style="text-align:left;" id="fsc_CID1" name="fsc_CID" >
                <option value="">Select</option>
                <option value="1">Webmaster</option>
                <option value="2">Managing Editor</option>
                <option value="3">Site Owner</option>
                </select>
      </div>

        <div style="text-align:left; padding-top:5px;">
                <label for="fsc_name1">Name:<span class="required"> *</span></label>
        </div>
        <div style="text-align:left;">
                <input style="text-align:left; margin:0;" type="text" id="fsc_name1" name="fsc_name" value=""  size="40" />
        </div>

        <div style="text-align:left; padding-top:5px;">
                <label for="fsc_email1">E-Mail Address:<span class="required"> *</span></label>
        </div>
        <div style="text-align:left;">
                <input style="text-align:left; margin:0;" type="email" id="fsc_email1" name="fsc_email" value=""  size="40" />
        </div>

        <div style="text-align:left; padding-top:5px;">
                 <label>Reason for Correspondence:<span class="required"> *</span></label>
        </div>
        <div style="text-align:left;">
                <span style="white-space:nowrap;"><input type="checkbox" style="width:13px;" id="fsc_ex_field1_1_1" name="fsc_ex_field1_1" value="selected"   />
                <label style="display:inline;" for="fsc_ex_field1_1_1">I have a comment</label></span>
                <br />
                <span style="white-space:nowrap;"><input type="checkbox" style="width:13px;" id="fsc_ex_field1_1_2" name="fsc_ex_field1_2" value="selected"   />
                <label style="display:inline;" for="fsc_ex_field1_1_2">I have a question</label></span>
                <br />
                <span style="white-space:nowrap;"><input type="checkbox" style="width:13px;" id="fsc_ex_field1_1_3" name="fsc_ex_field1_3" value="selected"   />
                <label style="display:inline;" for="fsc_ex_field1_1_3">I have a correction</label></span>
                <br />
                <span style="white-space:nowrap;"><input type="checkbox" style="width:13px;" id="fsc_ex_field1_1_4" name="fsc_ex_field1_4" value="selected"   />
                <label style="display:inline;" for="fsc_ex_field1_1_4">I have a submission</label></span>
                <br />
                <span style="white-space:nowrap;"><input type="checkbox" style="width:13px;" id="fsc_ex_field1_1_5" name="fsc_ex_field1_5" value="selected"   />
                <label style="display:inline;" for="fsc_ex_field1_1_5">I want to help MT</label></span>
                <br />
                <span style="white-space:nowrap;"><input type="checkbox" style="width:13px;" id="fsc_ex_field1_1_6" name="fsc_ex_field1_6" value="selected"   />
                <label style="display:inline;" for="fsc_ex_field1_1_6">Technical issues</label></span>
        </div>

        <div style="text-align:left; padding-top:5px;">
                <label for="fsc_ex_field1_2">Use this section to send an attachment.</label>
        </div>
        <div style="text-align:left;">
                <input style="text-align:left; margin:0;" type="file" id="fsc_ex_field1_2" name="fsc_ex_field2" value=""  size="20"  /><br /><span style="font-size:x-small;">Acceptable file types: doc,pdf,txt.<br />Maximum file size: 2mb.</span>        </div>

        <div style="text-align:left; padding-top:5px;">
                <label for="fsc_subject1">Subject:<span class="required"> *</span></label>
        </div>
        <div style="text-align:left;">
                 <input style="text-align:left; margin:0;" type="text" id="fsc_subject1" name="fsc_subject" value=""  size="40" />
        </div>

        <div style="text-align:left; padding-top:5px;">
                <label for="fsc_message1">Message:<span class="required"> *</span></label>
        </div>
        <div style="text-align:left;">
                <textarea style="text-align:left; margin:0;" id="fsc_message1" name="fsc_message"  cols="30" rows="10"></textarea>
        </div>

<div style="text-align:left; padding-top:5px;"> </div>
 <div style="width: 250px; height: 65px; padding-top:2px;">
    <img class="ctf-captcha" id="si_image_ctf1" style="border-style:none; margin:0; padding:0px; padding-right:5px; float:left;" src="http://mormonthink.com/contact-files/captcha/securimage_show.php?prefix=NeQyKy1eZGhlXtko" width="175" height="60" alt="CAPTCHA Image" title="CAPTCHA Image" />
    <input id="si_code_ctf_1" type="hidden" name="si_code_ctf_1" value="NeQyKy1eZGhlXtko" />
    <div id="si_refresh_ctf1">
      <a href="#" rel="nofollow" title="Refresh Image" onclick="fsc_captcha_refresh('1','noaudio','/contact-files/captcha','http://mormonthink.com/contact-files/captcha/securimage_show.php?prefix='); return false;">
      <img src="http://mormonthink.com/contact-files/captcha/images/refresh.png" width="22" height="20" alt="Refresh Image" style="border-style:none; margin:0; padding:0px; vertical-align:bottom;" onclick="this.blur();" /></a>
   </div>
 </div>

        <div style="text-align:left; padding-top:5px;">
                <label for="fsc_captcha_code1">CAPTCHA Code:<span class="required"> *</span></label>
        </div>
        <div style="text-align:left;">
                <input style="text-align:left; margin:0; width:50px;" type="text" value="" id="fsc_captcha_code1" name="fsc_captcha_code"  size="6" />
        </div>


<div style="text-align:left; padding-top:8px;">
  <input type="hidden" name="fsc_action" value="send" />
  <input type="hidden" name="fsc_form_id" value="1" />
  <input type="submit" id="fsc-submit-1" style="cursor:pointer; margin:0;" value="Submit" /> </div>

</form>
</div>
<!-- Fast Secure Contact Form PHP plugin 3.1 - end - FastSecureContactForm.com -->

&nbsp;<p></p>
<!-- InstanceEndEditable -->
 </div>
<!-- Main Body End --> 
 
 </div>
 </td>

 <td id="toccell" width="195px" class="invisible"> 
 </td>

 </tr>
 </table>
 
 <div class="push">
 </div>
 
</div>

<!-- Footer Start -->
<div id="footer">
 <div id="footer_spacer">
 </div>
<a href="/whoarewe.htm">About</a> <a href="mailto:mormonthink@hotmail.com">Contact Us</a> <a href="/map.htm">Site Map </a><a href="http://feeds.feedburner.com/MormonThink" title="MormonThink RSS feed"><img align="top" src="/img/rss.gif" alt="MormonThink RSS feed"/> RSS</a>
</div>
<!-- Footer End -->

</body>
<!-- InstanceEnd --></html>